# MaOr-Difficulties
unciv mod. oh? you say you want the game to be harder?, i heard you wrong? ohhhhh, so ill make a mod for both! pls star if you like!
